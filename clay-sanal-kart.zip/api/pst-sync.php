<?php
/**
 * Pulls the operator's PST.NET account into the shared ledger.
 * Card prices and fee percents are stored at 8% above the PST figures.
 * Imported movements keep the PST amount.
 * The bearer token stays in pst.config.php and is not returned to the browser.
 */

function pst_config_path(): string
{
    return dirname(__DIR__) . "/pst.config.php";
}

function pst_config(): array
{
    $path = pst_config_path();
    $config = is_file($path) ? include $path : [];
    if (!is_array($config)) {
        $config = [];
    }
    $token = trim((string) ($config["token"] ?? ""));
    $markup = (float) ($config["markup"] ?? 1.08);
    if ($markup < 1 || $markup > 3) {
        $markup = 1.08;
    }
    return ["token" => $token, "markup" => $markup];
}

function pst_save_token(string $token): bool
{
    $body = "<?php\nreturn [\n    \"token\" => " . var_export($token, true) . ",\n    \"markup\" => 1.08,\n];\n";
    return file_put_contents(pst_config_path(), $body, LOCK_EX) !== false;
}

function clay_pst_blank(): array
{
    return [
        "on" => false,
        "markup" => 8,
        "syncedAt" => "",
        "cards" => 0,
        "transactions" => 0,
        "orders" => 0,
        "loadSource" => 0,
        "issueSourceUsd" => 0,
        "transferSource" => 0,
        "error" => "",
        "tokenTail" => "",
    ];
}

function clay_pst_ensure(array &$settings): bool
{
    $blank = clay_pst_blank();
    if (!isset($settings["pst"]) || !is_array($settings["pst"])) {
        $settings["pst"] = $blank;
        return true;
    }
    $dirty = false;
    foreach ($blank as $key => $value) {
        if (!array_key_exists($key, $settings["pst"])) {
            $settings["pst"][$key] = $value;
            $dirty = true;
        }
    }
    return $dirty;
}

function pst_percent($raw): ?float
{
    if (!is_numeric($raw)) {
        return null;
    }
    $value = (float) $raw;
    if ($value < 0) {
        return null;
    }
    if ($value <= 1) {
        $value *= 100;
    }
    return $value;
}

function pst_usd($raw): ?float
{
    if (!is_numeric($raw)) {
        return null;
    }
    $value = (float) $raw;
    return $value >= 0 ? $value : null;
}

function pst_mask(string $mask): ?string
{
    $mask = strtoupper(trim($mask));
    if (preg_match("/^(\\d{6})[X*]{2,12}(\\d{4})$/", $mask, $hit)) {
        return $hit[1] . "******" . $hit[2];
    }
    $digits = (string) preg_replace("/\\D/", "", $mask);
    if (strlen($digits) < 10) {
        return null;
    }
    return substr($digits, 0, 6) . "******" . substr($digits, -4);
}

function pst_type(array $card, array $tariffs): string
{
    $tariff = $tariffs[(string) ($card["tariff_id"] ?? "")] ?? [];
    $blob = strtolower(trim(
        (string) ($card["description"] ?? "") . " "
        . (string) ($tariff["slug"] ?? "") . " "
        . (string) ($tariff["name"] ?? "")
    ));
    if (str_contains($blob, "tiktok")) {
        return "tiktok";
    }
    if (str_contains($blob, "google")) {
        return "google_ads";
    }
    if (str_contains($blob, "ultima")) {
        return "ultima";
    }
    return "facebook_ads";
}

function pst_status(array $card): string
{
    $simple = strtolower((string) ($card["simple_status"] ?? ""));
    if ($simple === "active") {
        return "aktif";
    }
    $text = strtolower((string) ($card["status_text"] ?? "") . " " . (string) ($card["status_name"] ?? ""));
    if (str_contains($text, "clos") || str_contains($text, "block") || str_contains($text, "expir") || str_contains($text, "delet")) {
        return "kapali";
    }
    return "donduruldu";
}

function pst_iso(string $value): string
{
    try {
        return (new DateTimeImmutable($value))->setTimezone(new DateTimeZone("UTC"))->format("Y-m-d\\TH:i:s.v\\Z");
    } catch (Exception $error) {
        return clay_now();
    }
}

function pst_kind(array $tx): string
{
    $blob = strtolower((string) ($tx["type"] ?? "") . " " . (string) ($tx["type_enum"] ?? "") . " " . (string) ($tx["description"] ?? ""));
    if (str_contains($blob, "refund") || str_contains($blob, "reversal")) {
        return "iade";
    }
    if (str_contains($blob, "topup") || str_contains($blob, "top-up") || str_contains($blob, "refill") || str_contains($blob, "replen")) {
        return "yukleme";
    }
    if (str_contains($blob, "transfer")) {
        return "transfer";
    }
    if (str_contains($blob, "buy") || str_contains($blob, "issue") || str_contains($blob, "order") || str_contains($blob, "fee")) {
        return "basim";
    }
    return "harcama";
}

function pst_tx_ok(array $tx): bool
{
    $text = strtolower((string) ($tx["status_text"] ?? "") . " " . (string) ($tx["custom_status"] ?? ""));
    foreach (["declin", "reject", "fail", "cancel", "error"] as $needle) {
        if (str_contains($text, $needle)) {
            return false;
        }
    }
    return true;
}

function pst_merchant(array $tx): string
{
    $merchant = $tx["merchant"] ?? "";
    if (is_array($merchant)) {
        $merchant = (string) ($merchant["name"] ?? $merchant["title"] ?? "");
    }
    $merchant = trim((string) $merchant);
    if ($merchant !== "") {
        return $merchant;
    }
    $description = trim((string) ($tx["description"] ?? ""));
    return $description !== "" ? $description : "PST hareketi";
}

function pst_rows(array $json): array
{
    $data = $json["data"] ?? null;
    if (is_array($data) && isset($data["data"]) && is_array($data["data"])) {
        $data = $data["data"];
    }
    if (!is_array($data)) {
        return [];
    }
    $rows = [];
    foreach ($data as $row) {
        if (is_array($row)) {
            $rows[] = $row;
        }
    }
    return $rows;
}

function pst_http(string $url, string $token): array
{
    if (!function_exists("curl_init")) {
        return ["_error" => 0];
    }
    $handle = curl_init($url);
    if ($handle === false) {
        return ["_error" => 0];
    }
    curl_setopt_array($handle, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer " . $token,
            "Accept: application/json",
        ],
    ]);
    $body = curl_exec($handle);
    $code = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
    curl_close($handle);
    if (!is_string($body) || $code < 200 || $code >= 300) {
        return ["_error" => $code];
    }
    $json = json_decode($body, true);
    return is_array($json) ? $json : ["_error" => 0];
}

function pst_list(string $path, string $token): array
{
    $next = "https://api.pst.net" . $path;
    $rows = [];
    for ($page = 0; $page < 8; $page += 1) {
        $json = pst_http($next, $token);
        if (isset($json["_error"])) {
            return $json;
        }
        foreach (pst_rows($json) as $row) {
            $rows[] = $row;
        }
        $link = $json["links"]["next"] ?? $json["next_page_url"] ?? null;
        if (!is_string($link) || $link === "") {
            break;
        }
        $next = $link;
    }
    return $rows;
}

function pst_owner(array $db, array $card): string
{
    $description = (string) ($card["description"] ?? "");
    if (preg_match("/(?:^|\\s)uye:([a-z0-9_]{3,24})\\b/i", $description, $hit)) {
        $name = strtolower($hit[1]);
        foreach ($db["users"] as $user) {
            if (strtolower((string) ($user["username"] ?? "")) === $name && ($user["role"] ?? "") === "uye") {
                return (string) $user["id"];
            }
        }
    }
    return "usr_admin";
}

function pst_balance_kurus(array $card): ?int
{
    foreach (["balance", "available", "available_balance", "card_balance", "amount"] as $key) {
        if (!isset($card[$key]) || !is_numeric($card[$key])) {
            continue;
        }
        $cents = (int) round(((float) $card[$key]) * 100);
        if ($cents < 0) {
            continue;
        }
        return clay_kurus($cents);
    }
    return null;
}

function clay_pst_apply(array &$db, array $cards, array $transactions, array $tariffs, array $fees): bool
{
    clay_pst_ensure($db["settings"]);
    $markup = (float) pst_config()["markup"];
    $byId = [];
    $issueSource = null;
    $loadSource = null;
    foreach ($tariffs as $tariff) {
        if (!is_array($tariff)) {
            continue;
        }
        $byId[(string) ($tariff["id"] ?? "")] = $tariff;
        $price = pst_usd($tariff["card_price"] ?? null);
        $load = pst_percent($tariff["fee_topup"] ?? null);
        if ($price !== null && ($issueSource === null || $price > $issueSource)) {
            $issueSource = $price;
        }
        if ($load !== null && ($loadSource === null || $load > $loadSource)) {
            $loadSource = $load;
        }
    }
    if ($loadSource === null && isset($fees["default_card_refill"])) {
        $loadSource = pst_percent($fees["default_card_refill"]);
    }
    $transferSource = isset($fees["withdraw"]) ? pst_percent($fees["withdraw"]) : null;
    if ($issueSource !== null && $issueSource > 0) {
        $db["settings"]["issueFeeKurus"] = clay_kurus((int) round($issueSource * $markup * 100));
    }
    if ($loadSource !== null && $loadSource > 0) {
        $db["settings"]["loadFeePercent"] = round($loadSource * $markup, 2);
    }
    if ($transferSource !== null && $transferSource > 0) {
        $db["settings"]["transferFeePercent"] = round($transferSource * $markup, 2);
    }

    $cardIndex = [];
    foreach ($db["cards"] as $i => $card) {
        $cardIndex[(string) ($card["id"] ?? "")] = $i;
    }
    $orderIndex = [];
    foreach ($db["orders"] as $i => $order) {
        $orderIndex[(string) ($order["id"] ?? "")] = $i;
    }
    $txIndex = [];
    foreach ($db["transactions"] as $i => $entry) {
        if (!empty($entry["ref"])) {
            $txIndex[(string) $entry["ref"]] = $i;
        }
    }

    $cardCount = 0;
    $knownBalance = [];
    foreach ($cards as $card) {
        if (!is_array($card) || !isset($card["id"])) {
            continue;
        }
        $mask = pst_mask((string) ($card["mask"] ?? ""));
        if ($mask === null) {
            continue;
        }
        $pstId = (string) $card["id"];
        $id = "crd_pst_" . preg_replace("/\\D/", "", $pstId);
        if ($id === "crd_pst_") {
            continue;
        }
        $owner = pst_owner($db, $card);
        if (clay_user_index($db, $owner) < 0) {
            $owner = "usr_admin";
        }
        if (clay_user_index($db, $owner) < 0) {
            continue;
        }
        $tariff = $byId[(string) ($card["tariff_id"] ?? "")] ?? [];
        $label = trim((string) ($card["description"] ?? ""));
        if ($label === "") {
            $label = trim((string) ($tariff["name"] ?? ""));
        }
        if ($label === "") {
            $label = "PST " . substr($mask, -4);
        }
        $label = mb_substr($label, 0, 32);
        $available = pst_balance_kurus($card);
        if ($available !== null) {
            $knownBalance[$id] = $available;
        }
        $created = pst_iso((string) ($card["ordered_at"] ?? clay_now()));
        $row = [
            "id" => $id,
            "userId" => $owner,
            "type" => pst_type($card, $byId),
            "label" => $label,
            "limit" => $available ?? 0,
            "spent" => 0,
            "pan" => $mask,
            "bin" => substr($mask, 0, 6),
            "binLabel" => "PST",
            "expiry" => "12/29",
            "cvv" => "•••",
            "holder" => clay_holder((string) ($card["holder_name"] ?? "CLAY")),
            "status" => pst_status($card),
            "readyAt" => null,
            "period" => 1,
            "createdAt" => $created,
            "feeDueAt" => null,
        ];
        if (isset($cardIndex[$id])) {
            $keep = $db["cards"][$cardIndex[$id]];
            $row["period"] = $keep["period"] ?? 1;
            if ($available === null) {
                $row["limit"] = (int) ($keep["limit"] ?? 0);
            }
            $db["cards"][$cardIndex[$id]] = $row;
        } else {
            $db["cards"][] = $row;
            $cardIndex[$id] = count($db["cards"]) - 1;
        }
        $price = pst_usd($tariff["card_price"] ?? null);
        $fee = $price === null ? 0 : clay_kurus((int) round($price * 100));
        $orderId = "ord_pst_" . preg_replace("/\\D/", "", $pstId);
        $orderStatus = $row["status"] === "kapali" ? "iptal" : "hazir";
        $order = [
            "id" => $orderId,
            "userId" => $owner,
            "cardId" => $id,
            "type" => $row["type"],
            "label" => $label,
            "limit" => $row["limit"],
            "fee" => $fee,
            "status" => $orderStatus,
            "createdAt" => $created,
            "readyAt" => null,
        ];
        if (isset($orderIndex[$orderId])) {
            $db["orders"][$orderIndex[$orderId]] = $order;
        } else {
            $db["orders"][] = $order;
            $orderIndex[$orderId] = count($db["orders"]) - 1;
        }
        $cardCount += 1;
    }

    $spentByCard = [];
    $txCount = 0;
    foreach ($transactions as $tx) {
        if (!is_array($tx) || !isset($tx["id"])) {
            continue;
        }
        $ref = "pst:" . preg_replace("/\\D/", "", (string) $tx["id"]);
        if ($ref === "pst:") {
            continue;
        }
        $cardKey = isset($tx["card_id"]) ? "crd_pst_" . preg_replace("/\\D/", "", (string) $tx["card_id"]) : "";
        $cardId = ($cardKey !== "crd_pst_" && isset($cardIndex[$cardKey])) ? $cardKey : null;
        $owner = "usr_admin";
        if ($cardId !== null) {
            $owner = (string) $db["cards"][$cardIndex[$cardId]]["userId"];
        }
        $usd = is_numeric($tx["amount"] ?? null) ? (float) $tx["amount"] : 0.0;
        $cents = (int) round($usd * 100);
        $amount = (int) round($cents * 49.3929);
        $kind = pst_kind($tx);
        $ok = pst_tx_ok($tx);
        $when = pst_iso((string) ($tx["processed_at"] ?? $tx["created_at"] ?? clay_now()));
        $entry = [
            "id" => "tx_" . $ref,
            "userId" => $owner,
            "cardId" => $cardId,
            "kind" => $kind,
            "title" => mb_substr(pst_merchant($tx), 0, 80),
            "note" => "PST hareketi. " . trim((string) ($tx["description"] ?? "")),
            "amount" => $amount,
            "usdMinor" => $cents,
            "status" => $ok ? "tamamlandi" : "reddedildi",
            "createdAt" => $when,
            "ref" => $ref,
        ];
        if (isset($txIndex[$ref])) {
            $db["transactions"][$txIndex[$ref]] = $entry;
        } else {
            $db["transactions"][] = $entry;
            $txIndex[$ref] = count($db["transactions"]) - 1;
        }
        if ($ok && $cardId !== null && $kind === "harcama" && $amount < 0) {
            $spentByCard[$cardId] = ($spentByCard[$cardId] ?? 0) + (-$amount);
        }
        $txCount += 1;
    }

    foreach ($spentByCard as $id => $spent) {
        $index = $cardIndex[$id];
        $db["cards"][$index]["spent"] = $spent;
        if (isset($knownBalance[$id])) {
            $db["cards"][$index]["limit"] = $knownBalance[$id] + $spent;
        } else {
            $db["cards"][$index]["limit"] = max((int) $db["cards"][$index]["limit"], $spent);
        }
    }

    $token = pst_config()["token"];
    $db["settings"]["pst"] = [
        "on" => $token !== "",
        "markup" => (int) round(($markup - 1) * 100),
        "syncedAt" => clay_now(),
        "cards" => $cardCount,
        "transactions" => $txCount,
        "orders" => $cardCount,
        "loadSource" => $loadSource ?? 0,
        "issueSourceUsd" => $issueSource ?? 0,
        "transferSource" => $transferSource ?? 0,
        "error" => "",
        "tokenTail" => $token === "" ? "" : substr($token, -4),
    ];
    return true;
}

function clay_pst_sync(array &$db, bool $force): bool
{
    clay_pst_ensure($db["settings"]);
    $config = pst_config();
    $tail = $config["token"] === "" ? "" : substr($config["token"], -4);
    $changed = ($db["settings"]["pst"]["tokenTail"] ?? "") !== $tail;
    $db["settings"]["pst"]["tokenTail"] = $tail;
    if ($config["token"] === "") {
        if (($db["settings"]["pst"]["on"] ?? false) || ($db["settings"]["pst"]["error"] ?? "") !== "") {
            $changed = true;
        }
        $db["settings"]["pst"]["on"] = false;
        $db["settings"]["pst"]["error"] = "";
        return $changed;
    }
    $seen = clay_ms((string) ($db["settings"]["pst"]["syncedAt"] ?? ""));
    if (!$force && $seen > 0 && (int) round(microtime(true) * 1000) - $seen < 15000) {
        return false;
    }
    $cards = pst_list("/integration/members/cards", $config["token"]);
    $transactions = pst_list("/integration/transactions-v2?sort=processed_at&direction=desc", $config["token"]);
    $tariffs = pst_list("/integration/user/tariff", $config["token"]);
    $feeJson = pst_http("https://api.pst.net/integration/dictionary/fees", $config["token"]);
    if (isset($cards["_error"]) || isset($transactions["_error"]) || isset($tariffs["_error"]) || isset($feeJson["_error"])) {
        $code = (int) ($cards["_error"] ?? $transactions["_error"] ?? $tariffs["_error"] ?? $feeJson["_error"] ?? 0);
        $db["settings"]["pst"]["on"] = true;
        $db["settings"]["pst"]["syncedAt"] = clay_now();
        $db["settings"]["pst"]["error"] = $code === 401 ? "PST anahtarı kabul edilmedi." : "PST yanıt vermedi.";
        $db["settings"]["pst"]["tokenTail"] = $tail;
        return true;
    }
    $fees = is_array($feeJson["data"] ?? null) ? $feeJson["data"] : [];
    return clay_pst_apply($db, $cards, $transactions, $tariffs, $fees);
}
